"""
API Test Script
Test the Medical Insurance API endpoints
"""

import requests
import json

# Configuration
BASE_URL = "http://localhost:8000"

def test_health():
    """Test the health check endpoint"""
    print("Testing /health endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/health")
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_models():
    """Test the models list endpoint"""
    print("\nTesting /models endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/models")
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_predict():
    """Test the prediction endpoint"""
    print("\nTesting /predict endpoint...")
    
    # Sample data
    payload = {
        "input_data": {
            "age": 30,
            "bmi": 25.5,
            "children": 2,
            "region_encoded": 0,
            "smoker_encoded": 0,
            "sex_encoded": 1
        },
        "selected_models": ["linear"]
    }
    
    try:
        response = requests.post(f"{BASE_URL}/predict", json=payload)
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"Error: {e}")
        return False

def test_invalid_input():
    """Test with invalid input to check validation"""
    print("\nTesting validation with invalid input...")
    
    # Invalid BMI
    payload = {
        "input_data": {
            "age": 30,
            "bmi": 150,  # Invalid - too high
            "children": 2,
            "region_encoded": 0,
            "smoker_encoded": 0,
            "sex_encoded": 1
        },
        "selected_models": ["linear"]
    }
    
    try:
        response = requests.post(f"{BASE_URL}/predict", json=payload)
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 422  # Validation error expected
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("Medical Insurance API Test Suite")
    print("=" * 60)
    
    tests = [
        ("Health Check", test_health),
        ("Models List", test_models),
        ("Prediction", test_predict),
        ("Input Validation", test_invalid_input)
    ]
    
    results = []
    for name, test_func in tests:
        result = test_func()
        results.append((name, result))
        print()
    
    print("=" * 60)
    print("Test Results Summary")
    print("=" * 60)
    
    for name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{name}: {status}")
    
    total = len(results)
    passed = sum(1 for _, r in results if r)
    print(f"\nTotal: {passed}/{total} tests passed")
