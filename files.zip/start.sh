#!/bin/bash

# Medical Insurance App - Quick Start Script
# This script helps you set up and run the application quickly

set -e  # Exit on error

echo "🏥 Medical Insurance Cost Predictor - Quick Start"
echo "=================================================="
echo ""

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check if Docker is installed
echo "Checking prerequisites..."
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi
print_success "Docker is installed"

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi
print_success "Docker Compose is installed"

echo ""

# Check if models directory exists
if [ ! -d "backend/models" ]; then
    print_warning "Creating backend/models directory..."
    mkdir -p backend/models
fi

# Check if any .joblib files exist
if [ -z "$(ls -A backend/models/*.joblib 2>/dev/null)" ]; then
    print_warning "No .joblib model files found in backend/models/"
    echo "Please add your trained model files to backend/models/ before running the app."
    echo ""
    read -p "Do you want to continue anyway? (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    MODEL_COUNT=$(ls -1 backend/models/*.joblib 2>/dev/null | wc -l)
    print_success "Found $MODEL_COUNT model file(s)"
fi

echo ""

# Ask user what to do
echo "What would you like to do?"
echo "1) Start the application (build and run)"
echo "2) Stop the application"
echo "3) Rebuild the application"
echo "4) View logs"
echo "5) Clean up (remove containers and images)"
echo ""
read -p "Enter your choice (1-5): " choice

case $choice in
    1)
        echo ""
        echo "Starting the application..."
        docker-compose up --build -d
        echo ""
        print_success "Application started successfully!"
        echo ""
        echo "Access the application:"
        echo "  Frontend: http://localhost:8501"
        echo "  Backend API: http://localhost:8000"
        echo "  API Docs: http://localhost:8000/docs"
        echo ""
        echo "Default credentials:"
        echo "  Username: admin"
        echo "  Password: secure123"
        echo ""
        echo "To view logs: docker-compose logs -f"
        echo "To stop: docker-compose down"
        ;;
    2)
        echo ""
        echo "Stopping the application..."
        docker-compose down
        print_success "Application stopped"
        ;;
    3)
        echo ""
        echo "Rebuilding the application..."
        docker-compose down
        docker-compose build --no-cache
        docker-compose up -d
        print_success "Application rebuilt and started"
        ;;
    4)
        echo ""
        echo "Viewing logs (press Ctrl+C to exit)..."
        docker-compose logs -f
        ;;
    5)
        echo ""
        read -p "This will remove all containers and images. Continue? (y/n) " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            docker-compose down --rmi all --volumes
            print_success "Cleanup complete"
        else
            echo "Cleanup cancelled"
        fi
        ;;
    *)
        print_error "Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "Done! 🎉"
