"""
Medical Insurance Cost Prediction - Frontend
Streamlit application with authentication, model selection, and predictions
"""

import streamlit as st
import requests
import pandas as pd
import os
from typing import List
import time

# Configuration
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")
APP_USER = os.getenv("APP_USER", "admin")
APP_PASS = os.getenv("APP_PASS", "admin123")

# Page configuration
st.set_page_config(
    page_title="Medical Insurance Cost Predictor",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)


def check_backend_health():
    """
    Check if backend API is available and responsive
    """
    try:
        response = requests.get(f"{BACKEND_URL}/health", timeout=5)
        return response.status_code == 200
    except Exception as e:
        st.error(f"⚠️ Backend not available: {str(e)}")
        return False


def get_available_models():
    """
    Fetch list of available models from backend
    """
    try:
        response = requests.get(f"{BACKEND_URL}/models", timeout=5)
        if response.status_code == 200:
            return response.json()["models"]
        return []
    except Exception as e:
        st.error(f"Error fetching models: {str(e)}")
        return []


def login_form():
    """
    Display login form and handle authentication
    Simple username/password authentication
    """
    st.title("🏥 Medical Insurance Cost Predictor")
    st.markdown("---")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.subheader("🔐 Login Required")
        
        with st.form("login_form"):
            username = st.text_input("Username", placeholder="Enter username")
            password = st.text_input("Password", type="password", placeholder="Enter password")
            
            col_a, col_b = st.columns(2)
            with col_a:
                submit = st.form_submit_button("Login", use_container_width=True)
            
            if submit:
                # Simple authentication check
                if username == APP_USER and password == APP_PASS:
                    st.session_state.authenticated = True
                    st.session_state.username = username
                    st.success("✅ Login successful!")
                    time.sleep(1)
                    st.rerun()
                else:
                    st.error("❌ Invalid username or password")
        
        # Display hint for demo purposes
        st.info(f"💡 Demo credentials - Username: `{APP_USER}` | Password: `{APP_PASS}`")


def logout_button():
    """
    Display logout button in sidebar
    """
    if st.sidebar.button("🚪 Logout", use_container_width=True):
        st.session_state.authenticated = False
        st.session_state.username = None
        st.rerun()


def model_selection_panel(available_models: List[dict]):
    """
    Display model selection checkboxes
    
    Args:
        available_models: List of model dictionaries from backend
        
    Returns:
        List of selected model keys
    """
    st.sidebar.subheader("🤖 Select Models")
    st.sidebar.markdown("Choose one or more prediction models:")
    
    selected_models = []
    
    # Add "Select All" option
    select_all = st.sidebar.checkbox("Select All Models", value=False)
    
    st.sidebar.markdown("---")
    
    for model in available_models:
        if model["loaded"]:
            # Pre-select if "Select All" is checked
            default_value = select_all
            
            if st.sidebar.checkbox(
                f"✓ {model['name']}", 
                value=default_value,
                key=f"model_{model['key']}"
            ):
                selected_models.append(model['key'])
        else:
            st.sidebar.checkbox(
                f"✗ {model['name']} (Not Available)", 
                value=False, 
                disabled=True,
                key=f"model_{model['key']}_disabled"
            )
    
    return selected_models


def input_form():
    """
    Display and handle the insurance data input form
    
    Returns:
        Dictionary with form data or None if not submitted
    """
    st.sidebar.subheader("📋 Insurance Details")
    st.sidebar.markdown("Enter the required information:")
    
    with st.sidebar.form(key="insurance_form"):
        # Age input with validation hint
        age = st.number_input(
            "Age",
            min_value=18,
            max_value=100,
            value=30,
            help="Enter age between 18 and 100 years"
        )
        
        # BMI input with calculation hint
        bmi = st.number_input(
            "BMI (Body Mass Index)",
            min_value=10.0,
            max_value=80.0,
            value=25.0,
            step=0.1,
            help="Normal BMI range: 18.5-24.9. Calculate: weight(kg) / height(m)²"
        )
        
        # Children input
        children = st.number_input(
            "Number of Children",
            min_value=0,
            max_value=10,
            value=0,
            help="Number of dependents covered"
        )
        
        # Region selection with dropdown for better UX
        region_options = {
            "Southwest": 0,
            "Southeast": 1,
            "Northwest": 2,
            "Northeast": 3
        }
        region = st.selectbox(
            "Region",
            options=list(region_options.keys()),
            help="Select your region"
        )
        region_encoded = region_options[region]
        
        # Smoker status with radio buttons
        smoker = st.radio(
            "Smoker Status",
            options=["No", "Yes"],
            horizontal=True,
            help="Current smoking status"
        )
        smoker_encoded = 1 if smoker == "Yes" else 0
        
        # Sex selection with radio buttons
        sex = st.radio(
            "Sex",
            options=["Male", "Female"],
            horizontal=True,
            help="Biological sex"
        )
        sex_encoded = 0 if sex == "Male" else 1
        
        st.markdown("---")
        
        # Submit and Reset buttons
        col1, col2 = st.columns(2)
        with col1:
            submit = st.form_submit_button("🔮 Predict", use_container_width=True)
        with col2:
            reset = st.form_submit_button("🔄 Reset", use_container_width=True)
        
        if reset:
            st.rerun()
        
        if submit:
            return {
                "age": age,
                "bmi": bmi,
                "children": children,
                "region_encoded": region_encoded,
                "smoker_encoded": smoker_encoded,
                "sex_encoded": sex_encoded
            }
    
    return None


def display_predictions(predictions: dict, input_summary: dict):
    """
    Display prediction results in a clean format
    
    Args:
        predictions: Dictionary of predictions from backend
        input_summary: Summary of input parameters
    """
    st.markdown("## 📊 Prediction Results")
    
    # Display input summary
    with st.expander("📝 Input Summary", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Age", f"{input_summary['age']} years")
            st.metric("BMI", f"{input_summary['bmi']:.1f}")
        
        with col2:
            st.metric("Children", input_summary['children'])
            st.metric("Region", input_summary['region'])
        
        with col3:
            st.metric("Smoker", input_summary['smoker'])
            st.metric("Sex", input_summary['sex'])
    
    st.markdown("---")
    
    # Display predictions from each model
    st.subheader("💰 Predicted Insurance Costs")
    
    successful_predictions = []
    
    for model_key, result in predictions.items():
        if result['status'] == 'success':
            successful_predictions.append({
                'Model': result['model_name'],
                'Predicted Cost': result['formatted']
            })
            
            # Display each prediction in a card-like format
            with st.container():
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.markdown(f"**{result['model_name']}**")
                with col2:
                    st.success(f"**{result['formatted']}**")
        
        elif result['status'] == 'unavailable':
            st.warning(f"⚠️ {result['model_name']}: Model not available")
        
        elif result['status'] == 'error':
            st.error(f"❌ {result['model_name']}: Prediction failed")
    
    # Show comparison table if multiple models were used
    if len(successful_predictions) > 1:
        st.markdown("---")
        st.subheader("📈 Model Comparison")
        df = pd.DataFrame(successful_predictions)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        # Calculate average
        costs = [float(p['Predicted Cost'].replace('INR ', '').replace(',', '')) 
                for p in successful_predictions]
        avg_cost = sum(costs) / len(costs)
        st.info(f"**Average Predicted Cost:** INR {avg_cost:,.2f}")


def main():
    """
    Main application function
    Handles authentication and main app flow
    """
    # Initialize session state
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    
    # Show login form if not authenticated
    if not st.session_state.authenticated:
        login_form()
        return
    
    # Main application (after authentication)
    st.title("🏥 Medical Insurance Cost Predictor")
    st.markdown(f"Welcome, **{st.session_state.username}**! 👋")
    st.markdown("---")
    
    # Check backend health
    if not check_backend_health():
        st.error("❌ Cannot connect to backend server. Please ensure it's running.")
        st.info(f"Backend URL: `{BACKEND_URL}`")
        logout_button()
        return
    
    st.success("✅ Connected to backend server")
    
    # Get available models
    available_models = get_available_models()
    
    if not available_models:
        st.error("No models available from backend")
        logout_button()
        return
    
    # Sidebar: Logout button
    logout_button()
    st.sidebar.markdown("---")
    
    # Sidebar: Model selection
    selected_models = model_selection_panel(available_models)
    
    st.sidebar.markdown("---")
    
    # Sidebar: Input form
    form_data = input_form()
    
    # Main area: Show instructions or predictions
    if form_data is None:
        # Show instructions when no prediction is made
        st.info("👈 Fill in the form and select models in the sidebar, then click **Predict**")
        
        st.markdown("### 📚 How to Use")
        st.markdown("""
        1. **Select Models**: Choose one or more prediction models from the sidebar
        2. **Enter Details**: Fill in your insurance information
        3. **Predict**: Click the predict button to see cost estimates
        4. **Compare**: If multiple models are selected, view a comparison table
        """)
        
        st.markdown("### ℹ️ About the Models")
        for model in available_models:
            if model['loaded']:
                st.markdown(f"- ✅ **{model['name']}**: Available")
            else:
                st.markdown(f"- ❌ **{model['name']}**: Not available")
    
    else:
        # Validate model selection
        if not selected_models:
            st.warning("⚠️ Please select at least one model from the sidebar")
            return
        
        # Show loading spinner while making prediction
        with st.spinner("🔮 Generating predictions..."):
            try:
                # Prepare request payload
                payload = {
                    "input_data": form_data,
                    "selected_models": selected_models
                }
                
                # Make API request
                response = requests.post(
                    f"{BACKEND_URL}/predict",
                    json=payload,
                    timeout=10
                )
                
                if response.status_code == 200:
                    result = response.json()
                    st.balloons()
                    display_predictions(result['predictions'], result['input_summary'])
                else:
                    st.error(f"❌ Prediction failed: {response.status_code}")
                    st.json(response.json())
            
            except requests.exceptions.Timeout:
                st.error("⏱️ Request timeout. Please try again.")
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")


if __name__ == "__main__":
    main()
