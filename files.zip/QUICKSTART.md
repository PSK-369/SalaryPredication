# 🚀 QUICK START GUIDE

Get up and running in 5 minutes!

## Prerequisites
- Docker & Docker Compose installed
- Your `.joblib` model files ready

## Steps

### 1. Add Your Models
```bash
# Copy your model files to backend/models/
cp /path/to/your/*.joblib backend/models/
```

Required files:
- `Linear.joblib`
- `poly.joblib`
- `poly1.joblib`
- `decesion.joblib`
- `ran.joblib`
- `knn.joblib`
- `lasso.joblib`

### 2. Start the Application
```bash
# Option A: Using the helper script
chmod +x start.sh
./start.sh

# Option B: Direct Docker Compose
docker-compose up --build
```

### 3. Access the Application

Open your browser:
- **Frontend**: http://localhost:8501
- **API Docs**: http://localhost:8000/docs

### 4. Login
- Username: `admin`
- Password: `secure123`

### 5. Make a Prediction

1. Select models from the sidebar
2. Fill in the insurance details
3. Click "🔮 Predict"
4. View results!

## 🔧 Common Commands

```bash
# Start
docker-compose up -d

# Stop
docker-compose down

# View logs
docker-compose logs -f

# Restart
docker-compose restart

# Rebuild
docker-compose build --no-cache
```

## 🆘 Troubleshooting

**Models not loading?**
- Check files are in `backend/models/`
- Check file permissions
- View logs: `docker-compose logs backend`

**Can't connect?**
- Wait 30 seconds for services to start
- Check: `docker-compose ps`
- Verify ports aren't in use

**Login not working?**
- Default: admin/secure123
- Change in `docker-compose.yml`

## 📚 Next Steps

- Read `README.md` for full documentation
- See `DEPLOYMENT.md` for production setup
- Run `python test_api.py` to test the API
- Customize authentication in `.env`

## ✅ Success Checklist

- [ ] Models placed in backend/models/
- [ ] Docker containers running
- [ ] Frontend accessible at :8501
- [ ] Backend health check passing
- [ ] Can login and make predictions

---

**Need help?** Check the full README.md or run `./start.sh` for interactive setup!
