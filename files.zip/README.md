# 🏥 Medical Insurance Cost Prediction System

A production-ready web application for predicting medical insurance costs using multiple machine learning models. Built with FastAPI backend and Streamlit frontend, fully containerized with Docker.

## 📋 Table of Contents
- [Features](#features)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Usage Guide](#usage-guide)
- [API Documentation](#api-documentation)
- [Customization](#customization)
- [Troubleshooting](#troubleshooting)

## ✨ Features

### Backend (FastAPI)
- ✅ **Multiple ML Models**: Support for 7 different regression models
- ✅ **Input Validation**: Pydantic models with comprehensive validation
- ✅ **Error Handling**: Robust exception handling with HTTP status codes
- ✅ **Health Checks**: Built-in health monitoring endpoints
- ✅ **CORS Support**: Configured for frontend communication
- ✅ **API Documentation**: Auto-generated Swagger/OpenAPI docs

### Frontend (Streamlit)
- ✅ **User Authentication**: Simple login system
- ✅ **Model Selection**: Choose single, multiple, or all models
- ✅ **Form Validation**: Input validation with helpful hints
- ✅ **Submit & Reset**: Clear form controls
- ✅ **Results Display**: Clean visualization of predictions
- ✅ **Model Comparison**: Side-by-side comparison table
- ✅ **Responsive Design**: Works on desktop and mobile

### DevOps
- ✅ **Docker Containerization**: Easy deployment with Docker
- ✅ **Docker Compose**: Single-command orchestration
- ✅ **Health Monitoring**: Automatic health checks
- ✅ **Environment Variables**: Configurable settings
- ✅ **Production Ready**: Follows best practices

## 📁 Project Structure

```
medical-insurance-app/
├── backend/
│   ├── models/                    # ML model files (.joblib)
│   │   ├── Linear.joblib
│   │   ├── poly.joblib
│   │   ├── poly1.joblib
│   │   ├── decesion.joblib
│   │   ├── ran.joblib
│   │   ├── knn.joblib
│   │   └── lasso.joblib
│   ├── main.py                    # FastAPI application
│   ├── Dockerfile                 # Backend container config
│   └── requirements.txt           # Python dependencies
├── frontend/
│   ├── app.py                     # Streamlit application
│   ├── Dockerfile                 # Frontend container config
│   └── requirements.txt           # Python dependencies
├── docker-compose.yml             # Service orchestration
└── README.md                      # This file
```

## 🔧 Prerequisites

- **Docker**: Version 20.10 or higher
- **Docker Compose**: Version 2.0 or higher
- **ML Models**: Pre-trained `.joblib` model files

OR (for local development without Docker):
- **Python**: Version 3.10 or higher
- **pip**: Latest version

## 🚀 Quick Start

### Option 1: Docker (Recommended)

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd medical-insurance-app
   ```

2. **Add your ML models**
   ```bash
   # Place your .joblib files in backend/models/
   cp /path/to/your/models/*.joblib backend/models/
   ```

3. **Start the application**
   ```bash
   docker-compose up --build
   ```

4. **Access the application**
   - Frontend: http://localhost:8501
   - Backend API: http://localhost:8000
   - API Docs: http://localhost:8000/docs

5. **Login**
   - Default username: `admin`
   - Default password: `secure123`

### Option 2: Local Development

1. **Backend Setup**
   ```bash
   cd backend
   pip install -r requirements.txt
   
   # Make sure models are in backend/models/
   python main.py
   # Backend runs on http://localhost:8000
   ```

2. **Frontend Setup** (in a new terminal)
   ```bash
   cd frontend
   pip install -r requirements.txt
   
   export BACKEND_URL=http://localhost:8000
   streamlit run app.py
   # Frontend runs on http://localhost:8501
   ```

## ⚙️ Configuration

### Environment Variables

#### Backend (backend/main.py)
- No environment variables required by default
- Models loaded from `models/` directory

#### Frontend (frontend/app.py)
- `BACKEND_URL`: Backend API URL (default: `http://localhost:8000`)
- `APP_USER`: Login username (default: `admin`)
- `APP_PASS`: Login password (default: `admin123`)

#### Docker Compose (docker-compose.yml)
```yaml
environment:
  - BACKEND_URL=http://backend:8000
  - APP_USER=admin
  - APP_PASS=secure123  # ⚠️ CHANGE IN PRODUCTION!
```

### Custom Ports

To change default ports, modify `docker-compose.yml`:

```yaml
services:
  backend:
    ports:
      - "9000:8000"  # Change 9000 to your desired port
  
  frontend:
    ports:
      - "9501:8501"  # Change 9501 to your desired port
```

## 📖 Usage Guide

### Step 1: Login
- Navigate to http://localhost:8501
- Enter credentials (default: admin/secure123)
- Click "Login"

### Step 2: Select Models
- In the sidebar, check the models you want to use
- You can select:
  - Single model
  - Multiple models
  - All models (using "Select All Models" checkbox)

### Step 3: Enter Insurance Details
Fill in the form with:
- **Age**: 18-100 years
- **BMI**: 10-80 (normal range: 18.5-24.9)
- **Children**: 0-10 dependents
- **Region**: Southwest, Southeast, Northwest, Northeast
- **Smoker**: Yes/No
- **Sex**: Male/Female

### Step 4: Get Predictions
- Click "🔮 Predict" button
- View predictions from selected models
- Compare results in the comparison table

### Step 5: Reset or Logout
- Click "🔄 Reset" to clear the form
- Click "🚪 Logout" to log out

## 📚 API Documentation

### Base URL
```
http://localhost:8000
```

### Endpoints

#### 1. Health Check
```http
GET /health
```
Returns API status and loaded models.

**Response:**
```json
{
  "status": "healthy",
  "models_loaded": 7,
  "available_models": ["linear", "poly2", "poly3", ...]
}
```

#### 2. Get Available Models
```http
GET /models
```
Returns list of all models with their status.

#### 3. Predict Insurance Cost
```http
POST /predict
```

**Request Body:**
```json
{
  "input_data": {
    "age": 30,
    "bmi": 25.5,
    "children": 2,
    "region_encoded": 0,
    "smoker_encoded": 0,
    "sex_encoded": 1
  },
  "selected_models": ["linear", "random_forest"]
}
```

**Response:**
```json
{
  "predictions": {
    "linear": {
      "model_name": "Linear Regression",
      "status": "success",
      "prediction": 12345.67,
      "formatted": "INR 12,345.67"
    }
  },
  "input_summary": {
    "age": 30,
    "bmi": 25.5,
    "smoker": "No",
    ...
  }
}
```

#### 4. Interactive API Docs
Visit http://localhost:8000/docs for Swagger UI documentation.

## 🔨 Customization

### Adding New Models

1. **Train and save your model**
   ```python
   import joblib
   joblib.dump(your_model, 'backend/models/your_model.joblib')
   ```

2. **Update MODEL_CONFIG in backend/main.py**
   ```python
   MODEL_CONFIG = {
       # ... existing models ...
       "your_model": {
           "file": "your_model.joblib",
           "name": "Your Model Name"
       }
   }
   ```

3. **Restart the application**
   ```bash
   docker-compose restart backend
   ```

### Changing Authentication

Edit `docker-compose.yml`:
```yaml
environment:
  - APP_USER=your_username
  - APP_PASS=your_secure_password
```

### Custom Styling (Frontend)

Modify `frontend/app.py` to add custom CSS:
```python
st.markdown("""
<style>
    .stButton>button {
        background-color: #4CAF50;
        color: white;
    }
</style>
""", unsafe_allow_html=True)
```

## 🐛 Troubleshooting

### Backend Issues

**Problem**: Models not loading
```bash
# Check if model files exist
ls -la backend/models/

# Check backend logs
docker-compose logs backend
```

**Problem**: Port 8000 already in use
```bash
# Change port in docker-compose.yml
ports:
  - "8001:8000"  # Use port 8001 instead
```

### Frontend Issues

**Problem**: Cannot connect to backend
```bash
# Check if backend is running
curl http://localhost:8000/health

# Check frontend logs
docker-compose logs frontend
```

**Problem**: Login not working
```bash
# Verify environment variables
docker-compose config
```

### Docker Issues

**Problem**: Build failures
```bash
# Clean rebuild
docker-compose down
docker-compose build --no-cache
docker-compose up
```

**Problem**: Container crashes
```bash
# View logs
docker-compose logs

# Check container status
docker-compose ps
```

## 📊 Model Information

The application supports these ML models:

| Model | Key | Description |
|-------|-----|-------------|
| Linear Regression | `linear` | Simple linear relationship |
| Polynomial (Degree 2) | `poly2` | Quadratic features |
| Polynomial (Degree 3) | `poly3` | Cubic features |
| Decision Tree | `decision_tree` | Tree-based decisions |
| Random Forest | `random_forest` | Ensemble of trees |
| K-Nearest Neighbors | `knn` | Distance-based prediction |
| Lasso Regression | `lasso` | L1 regularized regression |

## 🔐 Security Notes

⚠️ **IMPORTANT FOR PRODUCTION:**

1. **Change default credentials** in `docker-compose.yml`
2. **Use HTTPS** with SSL certificates
3. **Implement proper authentication** (JWT, OAuth, etc.)
4. **Add rate limiting** to prevent abuse
5. **Use secrets management** for sensitive data
6. **Enable CORS** only for trusted origins
7. **Regular security updates** for dependencies

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📧 Support

For issues or questions:
- Create an issue on GitHub
- Check existing documentation
- Review API docs at `/docs`

---

**Built with ❤️ using FastAPI and Streamlit**
