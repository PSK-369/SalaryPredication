# System Architecture

## 📐 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         User Browser                         │
│                     (http://localhost:8501)                  │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ HTTP
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                   Streamlit Frontend                         │
│                    (Port 8501)                               │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  • User Authentication                                  │ │
│  │  • Model Selection UI                                   │ │
│  │  • Input Form with Validation                           │ │
│  │  • Results Display & Comparison                         │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ REST API
                           │ (POST /predict)
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    FastAPI Backend                           │
│                     (Port 8000)                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  API Endpoints:                                         │ │
│  │  • GET  /health                                         │ │
│  │  • GET  /models                                         │ │
│  │  • POST /predict                                        │ │
│  │  • GET  /docs (Swagger UI)                              │ │
│  └────────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Features:                                              │ │
│  │  • Pydantic Validation                                  │ │
│  │  • Error Handling (HTTP Exceptions)                     │ │
│  │  • CORS Middleware                                      │ │
│  │  • Logging                                              │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           │ Model Loading
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    ML Models Layer                           │
│                  (Scikit-learn Models)                       │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐ │
│  │   Linear    │   Poly-2    │   Poly-3    │  Decision   │ │
│  │ Regression  │  Regression │  Regression │    Tree     │ │
│  └─────────────┴─────────────┴─────────────┴─────────────┘ │
│  ┌─────────────┬─────────────┬─────────────┐               │
│  │   Random    │     KNN     │    Lasso    │               │
│  │   Forest    │             │  Regression │               │
│  └─────────────┴─────────────┴─────────────┘               │
└─────────────────────────────────────────────────────────────┘
```

## 🔄 Data Flow

### 1. Prediction Request Flow

```
User → Login → Model Selection → Fill Form → Submit
  ↓
Frontend validates inputs locally
  ↓
POST /predict with JSON payload:
{
  "input_data": {...},
  "selected_models": [...]
}
  ↓
Backend receives request
  ↓
Pydantic validates input (age, bmi, etc.)
  ↓
For each selected model:
  - Load model from memory
  - Transform input features
  - Generate prediction
  - Format result
  ↓
Return predictions + input summary
  ↓
Frontend displays results
```

### 2. Startup Flow

```
Docker Compose starts
  ↓
┌─────────────────────┐         ┌──────────────────────┐
│  Backend Container  │         │  Frontend Container  │
└─────────────────────┘         └──────────────────────┘
          ↓                               ↓
    Load Models                    Wait for Backend
    from /models/                  Health Check
          ↓                               ↓
    Start FastAPI                  Start Streamlit
    on Port 8000                   on Port 8501
          ↓                               ↓
    Health Check                   Connect to Backend
    Passes ✓                       via BACKEND_URL
          ↓                               ↓
    Ready to Serve ←──────────────→ Ready for Users
```

## 🏗️ Component Details

### Frontend (Streamlit)

**File**: `frontend/app.py`

**Key Functions**:
- `login_form()` - Authentication UI
- `model_selection_panel()` - Model checkboxes
- `input_form()` - Insurance data form
- `display_predictions()` - Results visualization
- `check_backend_health()` - API connectivity check

**State Management**:
```python
st.session_state.authenticated  # Login status
st.session_state.username        # Current user
```

### Backend (FastAPI)

**File**: `backend/main.py`

**Key Classes**:
- `InsuranceInput` - Input validation model
- `PredictionRequest` - Request model
- `PredictionResponse` - Response model

**Key Functions**:
- `load_models()` - Load ML models at startup
- `predict_insurance_cost()` - Main prediction endpoint
- `get_available_models()` - List loaded models

**Model Configuration**:
```python
MODEL_CONFIG = {
    "linear": {"file": "Linear.joblib", "name": "..."},
    # ... more models
}
```

## 🔒 Security Architecture

```
┌─────────────────────────────────────────────┐
│            Security Layers                   │
├─────────────────────────────────────────────┤
│  1. Authentication (Frontend)                │
│     - Username/Password validation           │
│     - Session state management               │
├─────────────────────────────────────────────┤
│  2. Input Validation (Backend)               │
│     - Pydantic models                        │
│     - Range checking (age: 18-100, etc.)     │
│     - Type validation                        │
├─────────────────────────────────────────────┤
│  3. CORS Protection                          │
│     - Allowed origins configuration          │
│     - Credential handling                    │
├─────────────────────────────────────────────┤
│  4. Error Handling                           │
│     - HTTP exceptions                        │
│     - Graceful degradation                   │
│     - Logging without exposing secrets       │
├─────────────────────────────────────────────┤
│  5. Container Isolation                      │
│     - Docker network isolation               │
│     - Health checks                          │
│     - Resource limits                        │
└─────────────────────────────────────────────┘
```

## 🌐 Network Architecture

```
Docker Network: insurance_network
┌─────────────────────────────────────────────────┐
│                                                  │
│  ┌──────────────────┐    ┌──────────────────┐  │
│  │     Backend      │    │     Frontend     │  │
│  │  insurance_      │    │   insurance_     │  │
│  │   backend        │    │   frontend       │  │
│  │                  │    │                  │  │
│  │  Internal: 8000  │◄───┤  Internal: 8501  │  │
│  │  External: 8000  │    │  External: 8501  │  │
│  └──────────────────┘    └──────────────────┘  │
│         ▲                         ▲             │
└─────────┼─────────────────────────┼─────────────┘
          │                         │
          │                         │
    Host Port 8000            Host Port 8501
          │                         │
          └────────── ┌──────┐ ────┘
                      │ User │
                      └──────┘
```

## 📊 Input/Output Specification

### Input Features
```
┌──────────────────┬──────────┬────────────────────┐
│ Feature          │ Type     │ Valid Range        │
├──────────────────┼──────────┼────────────────────┤
│ age              │ int      │ 18 - 100           │
│ bmi              │ float    │ 10.0 - 80.0        │
│ children         │ int      │ 0 - 10             │
│ region_encoded   │ int      │ 0 - 3              │
│ smoker_encoded   │ int      │ 0 - 1              │
│ sex_encoded      │ int      │ 0 - 1              │
└──────────────────┴──────────┴────────────────────┘
```

### Output Format
```json
{
  "predictions": {
    "linear": {
      "model_name": "Linear Regression",
      "status": "success",
      "prediction": 12345.67,
      "formatted": "INR 12,345.67"
    }
  },
  "input_summary": {
    "age": 30,
    "bmi": 25.5,
    "region": "Southwest",
    "smoker": "No",
    "sex": "Male"
  }
}
```

## 🔄 State Diagram

```
┌─────────┐
│  Start  │
└────┬────┘
     │
     ▼
┌─────────────┐
│ Not Logged  │
│     In      │
└────┬────────┘
     │ Enter credentials
     ▼
┌─────────────┐       ┌──────────────┐
│  Validate   │──No──→│ Show Error   │
│ Credentials │       └──────┬───────┘
└────┬────────┘              │
     │ Yes                   │
     ▼                       │
┌─────────────┐              │
│  Logged In  │◄─────────────┘
│   (Home)    │
└────┬────────┘
     │ Select models
     ▼
┌─────────────┐
│   Models    │
│  Selected   │
└────┬────────┘
     │ Fill form
     ▼
┌─────────────┐       ┌──────────────┐
│  Validate   │──No──→│ Show Hints   │
│    Input    │       └──────┬───────┘
└────┬────────┘              │
     │ Yes                   │
     ▼                       │
┌─────────────┐              │
│   Submit    │◄─────────────┘
│     to      │
│   Backend   │
└────┬────────┘
     │
     ▼
┌─────────────┐       ┌──────────────┐
│  Receive    │──No──→│ Show Error   │
│  Response   │       └──────────────┘
└────┬────────┘
     │ Yes
     ▼
┌─────────────┐
│   Display   │
│ Predictions │
└─────────────┘
```

## 🎯 Key Design Decisions

1. **FastAPI for Backend**
   - Automatic API documentation
   - Built-in validation with Pydantic
   - Async support for future scaling
   - Type hints for better code quality

2. **Streamlit for Frontend**
   - Rapid development
   - Built-in form components
   - Session state management
   - Easy to customize

3. **Docker Compose**
   - Simple orchestration
   - Service isolation
   - Easy to deploy
   - Consistent environments

4. **Joblib for Models**
   - Fast serialization
   - Scikit-learn compatibility
   - Easy to version
   - Small file size

5. **RESTful API Design**
   - Stateless communication
   - Standard HTTP methods
   - JSON payload
   - Easy to test

## 📈 Scalability Considerations

- **Horizontal Scaling**: Add more backend replicas
- **Load Balancing**: Nginx or cloud load balancer
- **Caching**: Redis for frequent predictions
- **Database**: PostgreSQL for prediction history
- **CDN**: For static assets
- **Auto-scaling**: Based on CPU/memory metrics
