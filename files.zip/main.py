"""
Medical Insurance Cost Prediction API
FastAPI backend that loads ML models and provides prediction endpoints
"""

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator
from typing import List, Optional
import joblib
import numpy as np
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Medical Insurance Cost Predictor",
    description="API for predicting medical insurance costs using multiple ML models",
    version="1.0.0"
)

# CORS middleware - allows frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model configurations
MODEL_CONFIG = {
    "linear": {"file": "Linear.joblib", "name": "Linear Regression"},
    "poly2": {"file": "poly.joblib", "name": "Polynomial (Degree 2)"},
    "poly3": {"file": "poly1.joblib", "name": "Polynomial (Degree 3)"},
    "decision_tree": {"file": "decesion.joblib", "name": "Decision Tree"},
    "random_forest": {"file": "ran.joblib", "name": "Random Forest"},
    "knn": {"file": "knn.joblib", "name": "K-Nearest Neighbors"},
    "lasso": {"file": "lasso.joblib", "name": "Lasso Regression"}
}

# Global dictionary to store loaded models
models = {}


class InsuranceInput(BaseModel):
    """
    Input validation model for insurance cost prediction
    Ensures all inputs are within valid ranges
    """
    age: int = Field(..., ge=18, le=100, description="Age of the person (18-100)")
    bmi: float = Field(..., ge=10.0, le=80.0, description="Body Mass Index (10-80)")
    children: int = Field(..., ge=0, le=10, description="Number of children (0-10)")
    region_encoded: int = Field(
        ..., 
        ge=0, 
        le=3, 
        description="Region: 0=southwest, 1=southeast, 2=northwest, 3=northeast"
    )
    smoker_encoded: int = Field(
        ..., 
        ge=0, 
        le=1, 
        description="Smoker status: 0=no, 1=yes"
    )
    sex_encoded: int = Field(
        ..., 
        ge=0, 
        le=1, 
        description="Sex: 0=male, 1=female"
    )
    
    @validator('bmi')
    def validate_bmi(cls, v):
        """Ensure BMI is realistic"""
        if v < 15 or v > 60:
            logger.warning(f"Unusual BMI value: {v}")
        return v


class PredictionRequest(BaseModel):
    """
    Request model that includes input data and selected models
    """
    input_data: InsuranceInput
    selected_models: List[str] = Field(
        default=["linear"],
        description="List of models to use for prediction"
    )
    
    @validator('selected_models')
    def validate_models(cls, v):
        """Ensure selected models are valid"""
        valid_models = set(MODEL_CONFIG.keys())
        invalid = set(v) - valid_models
        if invalid:
            raise ValueError(f"Invalid models: {invalid}. Valid options: {valid_models}")
        return v


class PredictionResponse(BaseModel):
    """
    Response model with predictions from each selected model
    """
    predictions: dict
    input_summary: dict


def load_models():
    """
    Load all available ML models from the models directory
    Only loads models that exist to avoid errors
    """
    models_dir = Path("models")
    
    if not models_dir.exists():
        logger.error("Models directory not found!")
        return
    
    for model_key, config in MODEL_CONFIG.items():
        model_path = models_dir / config["file"]
        try:
            if model_path.exists():
                models[model_key] = joblib.load(model_path)
                logger.info(f"✓ Loaded {config['name']}")
            else:
                logger.warning(f"✗ Model file not found: {config['file']}")
        except Exception as e:
            logger.error(f"✗ Failed to load {config['name']}: {str(e)}")


@app.on_event("startup")
async def startup_event():
    """
    Load models when the application starts
    """
    logger.info("Starting Medical Insurance API...")
    load_models()
    logger.info(f"Loaded {len(models)} models successfully")


@app.get("/health")
async def health_check():
    """
    Health check endpoint for monitoring
    Returns the status of loaded models
    """
    return {
        "status": "healthy",
        "models_loaded": len(models),
        "available_models": list(models.keys())
    }


@app.get("/models")
async def get_available_models():
    """
    Get list of available models with their descriptions
    """
    available = []
    for key, config in MODEL_CONFIG.items():
        available.append({
            "key": key,
            "name": config["name"],
            "loaded": key in models
        })
    return {"models": available}


@app.post("/predict", response_model=PredictionResponse)
async def predict_insurance_cost(request: PredictionRequest):
    """
    Main prediction endpoint
    
    Takes insurance data and returns cost predictions from selected models
    
    Args:
        request: PredictionRequest with input data and model selection
        
    Returns:
        PredictionResponse with predictions from each model
        
    Raises:
        HTTPException: If models are not loaded or prediction fails
    """
    if not models:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="No models are loaded. Please check server logs."
        )
    
    # Convert input to numpy array for prediction
    input_data = request.input_data
    features = np.array([[
        input_data.age,
        input_data.bmi,
        input_data.children,
        input_data.region_encoded,
        input_data.smoker_encoded,
        input_data.sex_encoded
    ]])
    
    predictions = {}
    
    # Generate predictions from selected models
    for model_key in request.selected_models:
        if model_key not in models:
            logger.warning(f"Model {model_key} not available, skipping...")
            predictions[model_key] = {
                "model_name": MODEL_CONFIG[model_key]["name"],
                "status": "unavailable",
                "prediction": None
            }
            continue
        
        try:
            # Make prediction
            prediction = models[model_key].predict(features)[0]
            
            predictions[model_key] = {
                "model_name": MODEL_CONFIG[model_key]["name"],
                "status": "success",
                "prediction": float(abs(prediction)),  # Ensure positive value
                "formatted": f"INR {abs(prediction):,.2f}"
            }
            
        except Exception as e:
            logger.error(f"Prediction failed for {model_key}: {str(e)}")
            predictions[model_key] = {
                "model_name": MODEL_CONFIG[model_key]["name"],
                "status": "error",
                "prediction": None,
                "error": str(e)
            }
    
    # Create input summary for response
    input_summary = {
        "age": input_data.age,
        "bmi": input_data.bmi,
        "children": input_data.children,
        "region": ["Southwest", "Southeast", "Northwest", "Northeast"][input_data.region_encoded],
        "smoker": "Yes" if input_data.smoker_encoded == 1 else "No",
        "sex": "Male" if input_data.sex_encoded == 0 else "Female"
    }
    
    return PredictionResponse(
        predictions=predictions,
        input_summary=input_summary
    )


@app.get("/")
async def root():
    """
    Root endpoint with API information
    """
    return {
        "message": "Medical Insurance Cost Prediction API",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "models": "/models",
            "predict": "/predict (POST)",
            "docs": "/docs"
        }
    }


if __name__ == "__main__":
    import uvicorn
    # Custom host and port can be set via environment variables
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        log_level="info"
    )
