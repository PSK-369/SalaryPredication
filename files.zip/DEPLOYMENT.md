# Production Deployment Guide

This guide covers deploying the Medical Insurance Cost Predictor to production.

## 🔒 Security Checklist

Before deploying to production, ensure you:

### 1. Authentication
- [ ] Change default username and password
- [ ] Use environment variables for credentials
- [ ] Consider implementing JWT or OAuth2
- [ ] Add rate limiting to prevent brute force attacks

### 2. Environment Variables
- [ ] Create `.env` file from `.env.example`
- [ ] Never commit `.env` to version control
- [ ] Use secrets management (AWS Secrets Manager, Azure Key Vault, etc.)

### 3. CORS Configuration
```python
# In backend/main.py, update CORS settings:
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://yourdomain.com"],  # Specific domain only
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

### 4. HTTPS/SSL
- [ ] Obtain SSL certificate (Let's Encrypt, etc.)
- [ ] Configure reverse proxy (Nginx, Caddy)
- [ ] Redirect HTTP to HTTPS
- [ ] Use HSTS headers

### 5. Docker Security
- [ ] Use non-root user in containers
- [ ] Scan images for vulnerabilities
- [ ] Keep base images updated
- [ ] Use multi-stage builds to reduce image size

## 🚀 Deployment Options

### Option 1: Cloud Platform (AWS, GCP, Azure)

#### AWS Elastic Container Service (ECS)

1. **Build and push images to ECR**
```bash
# Authenticate to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com

# Tag images
docker tag insurance_backend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/insurance-backend:latest
docker tag insurance_frontend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/insurance-frontend:latest

# Push images
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/insurance-backend:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/insurance-frontend:latest
```

2. **Create ECS task definitions**
3. **Set up Application Load Balancer**
4. **Configure auto-scaling**

#### Google Cloud Run

```bash
# Build and deploy backend
gcloud builds submit --tag gcr.io/PROJECT-ID/insurance-backend backend/
gcloud run deploy insurance-backend --image gcr.io/PROJECT-ID/insurance-backend --platform managed

# Build and deploy frontend
gcloud builds submit --tag gcr.io/PROJECT-ID/insurance-frontend frontend/
gcloud run deploy insurance-frontend --image gcr.io/PROJECT-ID/insurance-frontend --platform managed
```

### Option 2: Virtual Private Server (VPS)

#### Using Docker Compose on VPS

1. **SSH into your server**
```bash
ssh user@your-server-ip
```

2. **Install Docker and Docker Compose**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
sudo apt-get install docker-compose
```

3. **Clone repository and configure**
```bash
git clone <repository-url>
cd medical-insurance-app
cp .env.example .env
nano .env  # Edit credentials
```

4. **Start application**
```bash
docker-compose up -d
```

5. **Set up Nginx reverse proxy**
```nginx
# /etc/nginx/sites-available/insurance-app
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

6. **Enable SSL with Let's Encrypt**
```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Option 3: Kubernetes

See `kubernetes/` directory for deployment manifests (if applicable).

## 📊 Monitoring and Logging

### 1. Application Logging

Add structured logging to your application:

```python
# backend/main.py
import logging
from pythonjsonlogger import jsonlogger

logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter()
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)
```

### 2. Health Checks

The application includes health check endpoints:
- Backend: `http://backend:8000/health`
- Frontend: `http://frontend:8501/_stcore/health`

### 3. Monitoring Tools

Consider using:
- **Prometheus** + **Grafana**: Metrics and dashboards
- **ELK Stack**: Centralized logging
- **Sentry**: Error tracking
- **New Relic/DataDog**: APM solutions

## 🔧 Performance Optimization

### 1. Backend Optimization

```python
# Use caching for model predictions
from functools import lru_cache

@lru_cache(maxsize=1000)
def get_prediction(features_tuple):
    features = np.array([features_tuple])
    return model.predict(features)[0]
```

### 2. Docker Image Optimization

```dockerfile
# Use multi-stage builds
FROM python:3.10-slim as builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --user -r requirements.txt

FROM python:3.10-slim
WORKDIR /app
COPY --from=builder /root/.local /root/.local
COPY . .
ENV PATH=/root/.local/bin:$PATH
CMD ["uvicorn", "main:app", "--host", "0.0.0.0"]
```

### 3. Database for Predictions (Optional)

If you need to store predictions:

```python
# Add PostgreSQL for storing predictions
from sqlalchemy import create_engine, Column, Integer, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True)
    age = Column(Integer)
    bmi = Column(Float)
    prediction = Column(Float)
    created_at = Column(DateTime)
```

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Build images
        run: docker-compose build
      
      - name: Run tests
        run: |
          docker-compose up -d
          python test_api.py
          docker-compose down
      
      - name: Deploy to production
        run: |
          # Add your deployment commands here
```

## 📈 Scaling Strategies

### Horizontal Scaling

```yaml
# docker-compose.yml
services:
  backend:
    deploy:
      replicas: 3
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
```

### Load Balancing

Use Nginx or cloud load balancers to distribute traffic across multiple instances.

### Caching

Implement Redis for caching frequent predictions:

```python
import redis
r = redis.Redis(host='localhost', port=6379)

# Cache prediction
cache_key = f"pred:{age}:{bmi}:{smoker}"
cached = r.get(cache_key)
if cached:
    return float(cached)
```

## 🆘 Troubleshooting Production Issues

### Check Logs
```bash
# Docker Compose
docker-compose logs -f backend
docker-compose logs -f frontend

# Kubernetes
kubectl logs -f deployment/insurance-backend
```

### Check Container Status
```bash
docker-compose ps
docker stats
```

### Database Connections
```bash
# Test backend health
curl http://localhost:8000/health

# Test with detailed logging
docker-compose up
```

## 📋 Pre-Launch Checklist

- [ ] All security measures implemented
- [ ] SSL certificate configured
- [ ] Monitoring and logging set up
- [ ] Backups configured
- [ ] Load testing completed
- [ ] Documentation updated
- [ ] Team trained on deployment process
- [ ] Rollback plan documented
- [ ] Rate limiting configured
- [ ] Error tracking enabled

## 📞 Support

For production support issues:
1. Check application logs
2. Review health check endpoints
3. Consult documentation
4. Contact development team

---

**Remember**: Always test in staging before deploying to production!
