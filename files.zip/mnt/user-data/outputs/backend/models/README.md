# ML Models Directory

Place your trained `.joblib` model files in this directory.

## Required Model Files

The application expects the following model files:

1. `Linear.joblib` - Linear Regression model
2. `poly.joblib` - Polynomial Regression (Degree 2) model
3. `poly1.joblib` - Polynomial Regression (Degree 3) model
4. `decesion.joblib` - Decision Tree model
5. `ran.joblib` - Random Forest model
6. `knn.joblib` - K-Nearest Neighbors model
7. `lasso.joblib` - Lasso Regression model

## Model Format

All models should be:
- Trained scikit-learn models
- Saved using `joblib.dump()`
- Expecting 6 input features in this order:
  1. age
  2. bmi
  3. children
  4. region_encoded
  5. smoker_encoded
  6. sex_encoded

## Example: Training and Saving a Model

```python
import joblib
from sklearn.linear_model import LinearRegression

# Train your model
model = LinearRegression()
model.fit(X_train, y_train)

# Save the model
joblib.dump(model, 'Linear.joblib')
```

## Note

- The application will still run even if some models are missing
- Missing models will be marked as "unavailable" in the UI
- At least one model should be present for predictions to work
